package manager;

import model.Event;
import java.util.ArrayList;
import java.io.*;

public class EventManager {
    private static EventManager instance;
    private ArrayList<Event> events;
    private static final String FILE_PATH = "src/data/events.txt";

    private EventManager() {
        events = new ArrayList<>();
        loadEventsFromFile();
    }

    public static EventManager getInstance() {
        if (instance == null) {
            instance = new EventManager();
        }
        return instance;
    }

    public void addEvent(Event event) {
        events.add(event);
        saveEventsToFile();
    }

    public void updateEvent(int index, Event updatedEvent) {
        if (index >= 0 && index < events.size()) {
            events.set(index, updatedEvent);
            saveEventsToFile();
        }
    }

    public void cancelEvent(int index) {
        if (index >= 0 && index < events.size()) {
            events.remove(index);
            saveEventsToFile();
        }
    }

    public ArrayList<Event> getEvents() {
        return events;
    }

    // Save events to file 
    public void saveEventsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Event e : events) {
                writer.write(serializeEvent(e));
                writer.newLine();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    // Load events from file
    public void loadEventsFromFile() {
        events.clear();
        File file = new File(FILE_PATH);
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Event e = deserializeEvent(line);
                if (e != null) events.add(e);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    // Helper: serialize Event
    private String serializeEvent(Event e) {
        // Escape commas in fields if needed
        String services = String.join(";", e.getOptionalServices());
        StringBuilder sb = new StringBuilder();
        sb.append(escape(e.getName())).append(",")
          .append(escape(e.getDate())).append(",")
          .append(escape(e.getStartTime())).append(",")
          .append(escape(e.getEndTime())).append(",")
          .append(escape(e.getVenue())).append(",")
          .append(escape(e.getType())).append(",")
          .append(e.getCapacity()).append(",")
          .append(e.getRegistrationFee()).append(",")
          .append(escape(String.join("|", e.getOptionalServices()))).append(",")
          .append(e.hasEarlyBirdDiscount()).append(",")
          .append(e.hasStaffDiscount());
        return sb.toString();
    }

 
    private Event deserializeEvent(String line) {
        try {
            String[] parts = line.split(",", -1);
            if (parts.length < 11) return null;
            String name = unescape(parts[0]);
            String date = unescape(parts[1]);
            String startTime = unescape(parts[2]);
            String endTime = unescape(parts[3]);
            String venue = unescape(parts[4]);
            String type = unescape(parts[5]);
            int capacity = Integer.parseInt(parts[6]);
            double registrationFee = Double.parseDouble(parts[7]);
            ArrayList<String> services = new ArrayList<>();
            if (!parts[8].isEmpty()) {
                for (String s : parts[8].split("|")) {
                    services.add(unescape(s));
                }
            }
            boolean earlyBirdDiscount = Boolean.parseBoolean(parts[9]);
            boolean staffDiscount = Boolean.parseBoolean(parts[10]);
            return new Event(name, date, startTime, endTime, venue, type, capacity, registrationFee, services, earlyBirdDiscount, staffDiscount);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }


    private String escape(String s) {
        return s == null ? "" : s.replace(",", "&#44;");
    }
    private String unescape(String s) {
        return s == null ? "" : s.replace("&#44;", ",");
    }
}

