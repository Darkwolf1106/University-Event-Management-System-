package gui;


import facade.GUIManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.List;
import java.util.*;

public class EventRegistrationWindow extends JFrame {

    private JTextField nameField;
    private JTextField idField;
    private JRadioButton studentRadio;
    private JRadioButton staffRadio;
    private JComboBox<String> eventDropdown;
    private JComboBox<String> addonDropdown1;
    private JComboBox<String> addonDropdown2;
    private JComboBox<String> staffDiscountDropdown;
    private JButton submitButton;
    private JButton backButton; 

    private Map<String, List<String>> eventAddOnsMap = new HashMap<>();
    private Set<String> staffDiscountEvents = new HashSet<>();

    public EventRegistrationWindow() {
        setTitle("Event Registration Form");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); 
        setLocationRelativeTo(null);
        setLayout(new BorderLayout()); 

        
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK); 
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); 

        JLabel headerLabel = new JLabel("EVENT REGISTRATION");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 36));
        headerLabel.setForeground(Color.WHITE); 
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH); 

        
        JPanel contentPanel = new JPanel(new GridBagLayout()); 
        contentPanel.setBackground(Color.WHITE); 
        contentPanel.setBorder(BorderFactory.createEmptyBorder(30, 200, 30, 200)); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); 
        gbc.fill = GridBagConstraints.HORIZONTAL; 

        Font labelFont = new Font("Arial", Font.PLAIN, 18);
        Font fieldFont = new Font("Arial", Font.PLAIN, 18);
        Font radioFont = new Font("Arial", Font.PLAIN, 16);

        
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST;
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(labelFont);
        contentPanel.add(nameLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        nameField = new JTextField(20);
        nameField.setFont(fieldFont);
        contentPanel.add(nameField, gbc);

        
        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.EAST;
        JLabel idLabel = new JLabel("ID:");
        idLabel.setFont(labelFont);
        contentPanel.add(idLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 1; gbc.anchor = GridBagConstraints.WEST;
        idField = new JTextField(20);
        idField.setFont(fieldFont);
        contentPanel.add(idField, gbc);

        
        gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.EAST;
        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setFont(labelFont);
        contentPanel.add(roleLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 2; gbc.anchor = GridBagConstraints.WEST;
        JPanel rolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        rolePanel.setOpaque(false); // Make transparent
        studentRadio = new JRadioButton("Student");
        staffRadio = new JRadioButton("Staff");
        studentRadio.setFont(radioFont);
        staffRadio.setFont(radioFont);
        studentRadio.setOpaque(false);
        staffRadio.setOpaque(false);
        ButtonGroup roleGroup = new ButtonGroup();
        roleGroup.add(studentRadio);
        roleGroup.add(staffRadio);
        rolePanel.add(studentRadio);
        rolePanel.add(staffRadio);
        contentPanel.add(rolePanel, gbc);

        
        gbc.gridx = 0; gbc.gridy = 3; gbc.anchor = GridBagConstraints.EAST;
        JLabel eventLabel = new JLabel("Choose Event:");
        eventLabel.setFont(labelFont);
        contentPanel.add(eventLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 3; gbc.anchor = GridBagConstraints.WEST;
        eventDropdown = new JComboBox<>();
        eventDropdown.setFont(fieldFont);
        contentPanel.add(eventDropdown, gbc);

        
        gbc.gridx = 0; gbc.gridy = 4; gbc.anchor = GridBagConstraints.EAST;
        JLabel addon1Label = new JLabel("Add-On Service 1 (RM10 each):");
        addon1Label.setFont(labelFont);
        contentPanel.add(addon1Label, gbc);
        gbc.gridx = 1; gbc.gridy = 4; gbc.anchor = GridBagConstraints.WEST;
        addonDropdown1 = new JComboBox<>();
        addonDropdown1.addItem("None");
        addonDropdown1.setFont(fieldFont);
        contentPanel.add(addonDropdown1, gbc);

        
        gbc.gridx = 0; gbc.gridy = 5; gbc.anchor = GridBagConstraints.EAST;
        JLabel addon2Label = new JLabel("Add-On Service 2 (RM10 each):");
        addon2Label.setFont(labelFont);
        contentPanel.add(addon2Label, gbc);
        gbc.gridx = 1; gbc.gridy = 5; gbc.anchor = GridBagConstraints.WEST;
        addonDropdown2 = new JComboBox<>();
        addonDropdown2.addItem("None");
        addonDropdown2.setFont(fieldFont);
        contentPanel.add(addonDropdown2, gbc);

        
        gbc.gridx = 0; gbc.gridy = 6; gbc.anchor = GridBagConstraints.EAST;
        JLabel discountLabel = new JLabel("Staff Discount Option:");
        discountLabel.setFont(labelFont);
        contentPanel.add(discountLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 6; gbc.anchor = GridBagConstraints.WEST;
        staffDiscountDropdown = new JComboBox<>();
        staffDiscountDropdown.addItem("None");
        staffDiscountDropdown.addItem("Apply Staff Discount");
        staffDiscountDropdown.setEnabled(false);
        staffDiscountDropdown.setFont(fieldFont);
        contentPanel.add(staffDiscountDropdown, gbc);

        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0)); 
        buttonPanel.setOpaque(false);

        submitButton = new JButton("SUBMIT REGISTRATION");
        submitButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        submitButton.setBackground(new Color(60, 179, 113)); 
        submitButton.setForeground(Color.BLACK); 
        submitButton.setFocusPainted(false);
        submitButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(40, 120, 80), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(submitButton);

        backButton = new JButton("BACK"); 
        backButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        backButton.setBackground(new Color(170, 180, 190)); 
        backButton.setForeground(Color.BLACK);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(120, 130, 140), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(backButton); 

        
        add(contentPanel, BorderLayout.CENTER);
        
        add(buttonPanel, BorderLayout.SOUTH);

        loadEventsFromFile();

        eventDropdown.addActionListener(e -> updateDropdowns());
        studentRadio.addActionListener(e -> updateDropdowns());
        staffRadio.addActionListener(e -> updateDropdowns());
        submitButton.addActionListener(e -> handleSubmit());

        
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIManager.getInstance().disposeWindow(EventRegistrationWindow.this); 
                GUIManager.getInstance().showStudentStaffDashboard(); 
            }
        });

        
    }

    private void loadEventsFromFile() {
        File file = new File("src/data/events.txt");
        if (!file.exists()) {
            eventDropdown.addItem("No events available");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 11) {
                    String eventName = parts[0].trim();
                    String addons = parts[8].trim();
                    String[] addonItems = addons.split("\\|");
                    eventAddOnsMap.put(eventName, Arrays.asList(addonItems));

                    eventDropdown.addItem(eventName);

                    if (parts[10].trim().equalsIgnoreCase("true")) {
                        staffDiscountEvents.add(eventName);
                    }
                }
            }
        } catch (IOException e) {
            eventDropdown.addItem("Error loading events");
        }
    }

    private void updateDropdowns() {
        addonDropdown1.removeAllItems();
        addonDropdown2.removeAllItems();
        addonDropdown1.addItem("None");
        addonDropdown2.addItem("None");

        String selectedEvent = (String) eventDropdown.getSelectedItem();
        if (selectedEvent != null && eventAddOnsMap.containsKey(selectedEvent)) {
            for (String addon : eventAddOnsMap.get(selectedEvent)) {
                if (!addon.equalsIgnoreCase("None") && !addon.isBlank()) {
                    addonDropdown1.addItem(addon);
                    addonDropdown2.addItem(addon);
                }
            }
        }

        if (staffRadio.isSelected() && selectedEvent != null && staffDiscountEvents.contains(selectedEvent)) {
            staffDiscountDropdown.setEnabled(true);
        } else {
            staffDiscountDropdown.setSelectedItem("None");
            staffDiscountDropdown.setEnabled(false);
        }
    }

    private void handleSubmit() {
        String name = nameField.getText().trim();
        String id = idField.getText().trim();
        String role = studentRadio.isSelected() ? "Student" : (staffRadio.isSelected() ? "Staff" : "");
        String selectedEvent = (String) eventDropdown.getSelectedItem();
        String selectedDiscount = staffRadio.isSelected() ? (String) staffDiscountDropdown.getSelectedItem() : "None";

        if (name.isEmpty() || id.isEmpty() || role.isEmpty() || selectedEvent == null || selectedEvent.startsWith("No")) {
            JOptionPane.showMessageDialog(this, "Please complete all fields.");
            return;
        }

        
        Set<String> addons = new LinkedHashSet<>();
        if (!"None".equals(addonDropdown1.getSelectedItem())) {
            addons.add((String) addonDropdown1.getSelectedItem());
        }
        if (!"None".equals(addonDropdown2.getSelectedItem())) {
            addons.add((String) addonDropdown2.getSelectedItem());
        }

        String addonString = addons.isEmpty() ? "None" : String.join(" | ", addons);

        try (FileWriter writer = new FileWriter("src/data/registrations.txt", true)) {
            writer.write(name + "," + id + "," + role + "," + selectedEvent + "," + selectedDiscount + "," + addonString + "\n");
            JOptionPane.showMessageDialog(this, "Registration successful!");
            GUIManager.getInstance().disposeWindow(this); 
            GUIManager.getInstance().showStudentStaffDashboard(); 
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving registration.");
        }
    }
}