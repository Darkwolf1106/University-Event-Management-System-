package gui;


import facade.GUIManager;
import manager.EventManager;
import model.Event;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class CancelEventWindow extends JFrame {
    private JComboBox<String> eventComboBox;
    private JButton cancelButton;
    private ArrayList<Event> events;
    private JButton backButton; 

    public CancelEventWindow() {
        setTitle("Cancel Event");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); 
        setLocationRelativeTo(null);
        setLayout(new BorderLayout()); 

        // --- Header Panel ---
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK); 
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); 

        JLabel headerLabel = new JLabel("CANCEL EVENT");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 36));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH); 

        // --- Main Content Panel ---
        JPanel contentPanel = new JPanel(new GridBagLayout()); 
        contentPanel.setBackground(Color.WHITE); 
        contentPanel.setBorder(BorderFactory.createEmptyBorder(50, 200, 50, 200)); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 10, 15, 10); 
        gbc.fill = GridBagConstraints.HORIZONTAL; 

        Font labelFont = new Font("Arial", Font.PLAIN, 18);
        Font dropdownFont = new Font("Arial", Font.PLAIN, 18);

        events = EventManager.getInstance().getEvents();
        eventComboBox = new JComboBox<>();
        eventComboBox.setFont(dropdownFont); 
        for (Event e : events) {
            eventComboBox.addItem(e.getName() + " (" + e.getDate() + ")");
        }

        
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST;
        JLabel selectEventLabel = new JLabel("Select Event to Cancel:");
        selectEventLabel.setFont(labelFont);
        contentPanel.add(selectEventLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        contentPanel.add(eventComboBox, gbc);

        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0)); 
        buttonPanel.setOpaque(false);

        cancelButton = new JButton("CANCEL EVENT");
       
        cancelButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        cancelButton.setBackground(new Color(70, 130, 180)); 
        cancelButton.setForeground(Color.BLACK); 
        cancelButton.setFocusPainted(false);
        cancelButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 100, 150), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(cancelButton);

        backButton = new JButton("BACK"); 
        backButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        backButton.setBackground(new Color(170, 180, 190));
        backButton.setForeground(Color.BLACK);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(120, 130, 140), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(backButton); 

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(30, 10, 10, 10);
        contentPanel.add(buttonPanel, gbc); 

        add(contentPanel, BorderLayout.CENTER); 

        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cancelEvent();
            }
        });

        
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIManager.getInstance().disposeWindow(CancelEventWindow.this); 
                GUIManager.getInstance().showEventOrganiserDashboard(); 
            }
        });

       
    }

    private void cancelEvent() {
        int idx = eventComboBox.getSelectedIndex();
        if (idx < 0) {
            JOptionPane.showMessageDialog(this, "Please select an event to cancel.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to cancel this event??", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            EventManager.getInstance().cancelEvent(idx);
            JOptionPane.showMessageDialog(this, "Event cancelled successfully!");
            GUIManager.getInstance().disposeWindow(this); 
            GUIManager.getInstance().showEventOrganiserDashboard(); 
        }
    }
}