package gui;

import facade.GUIManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class SignUpWindow extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JRadioButton studentRadio;
    private JRadioButton staffRadio;
    private JButton signUpButton;
    private JRadioButton eventOrganiserRadio;
    private JButton backButton; 
    public SignUpWindow() {
        setTitle("Sign Up Page");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK); 
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); 

        JLabel headerLabel = new JLabel("CREATE NEW ACCOUNT");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 36)); 
        headerLabel.setForeground(Color.WHITE); 
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH); 

       
        JPanel contentPanel = new JPanel(new GridBagLayout()); 
        contentPanel.setBackground(Color.WHITE); 
        contentPanel.setBorder(BorderFactory.createEmptyBorder(50, 200, 50, 200)); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 10, 15, 10); 
        gbc.fill = GridBagConstraints.HORIZONTAL; 

        gbc.gridx = 0; 
        gbc.gridy = 0; 
        gbc.anchor = GridBagConstraints.EAST; 
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        contentPanel.add(usernameLabel, gbc);

        gbc.gridx = 1; 
        gbc.gridy = 0; 
        gbc.anchor = GridBagConstraints.WEST; 
        usernameField = new JTextField(20); 
        usernameField.setFont(new Font("Arial", Font.PLAIN, 18));
        contentPanel.add(usernameField, gbc);

       
        gbc.gridx = 0; 
        gbc.gridy = 1; 
        gbc.anchor = GridBagConstraints.EAST;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        contentPanel.add(passwordLabel, gbc);

        gbc.gridx = 1; 
        gbc.gridy = 1; 
        gbc.anchor = GridBagConstraints.WEST;
        passwordField = new JPasswordField(20); 
        passwordField.setFont(new Font("Arial", Font.PLAIN, 18));
        contentPanel.add(passwordField, gbc);

       
        gbc.gridx = 0; 
        gbc.gridy = 2; 
        gbc.anchor = GridBagConstraints.EAST;
        JLabel roleLabel = new JLabel("Select Role:");
        roleLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        contentPanel.add(roleLabel, gbc);

        gbc.gridx = 1; 
        gbc.gridy = 2; 
        gbc.anchor = GridBagConstraints.WEST;
        JPanel rolePanel = new JPanel(new GridLayout(3, 1)); 
        rolePanel.setOpaque(false); 
        studentRadio = new JRadioButton("Student");
        staffRadio = new JRadioButton("Staff");
        eventOrganiserRadio = new JRadioButton("Event Organiser");

        studentRadio.setFont(new Font("Arial", Font.PLAIN, 16));
        staffRadio.setFont(new Font("Arial", Font.PLAIN, 16));
        eventOrganiserRadio.setFont(new Font("Arial", Font.PLAIN, 16));
        
        studentRadio.setOpaque(false);
        staffRadio.setOpaque(false);
        eventOrganiserRadio.setOpaque(false);

        ButtonGroup roleGroup = new ButtonGroup();
        roleGroup.add(studentRadio);
        roleGroup.add(staffRadio);
        roleGroup.add(eventOrganiserRadio);

        rolePanel.add(studentRadio);
        rolePanel.add(staffRadio);
        rolePanel.add(eventOrganiserRadio);
        contentPanel.add(rolePanel, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0)); 
        buttonPanel.setOpaque(false); 

        signUpButton = new JButton("SIGN UP");
        signUpButton.setFont(new Font("SansSerif", Font.BOLD, 24)); 
        signUpButton.setBackground(new Color(70, 130, 180)); 
        signUpButton.setForeground(Color.BLACK); 
        signUpButton.setFocusPainted(false); 
        signUpButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 100, 150), 2), 
            BorderFactory.createEmptyBorder(15, 30, 15, 30) 
        ));
        buttonPanel.add(signUpButton);

        backButton = new JButton("BACK"); 
        backButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        backButton.setBackground(new Color(170, 180, 190)); 
        backButton.setForeground(Color.BLACK);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(120, 130, 140), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(backButton); 

        add(contentPanel, BorderLayout.CENTER); 
        add(buttonPanel, BorderLayout.SOUTH);


        signUpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSignUp();
            }
        });

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIManager.getInstance().disposeWindow(SignUpWindow.this); 
                GUIManager.getInstance().showMainDashboard(); 
            }
        });

    }
    
    private void handleSignUp() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        String role = "";

        if (studentRadio.isSelected()) {
            role = "student";
        } else if (staffRadio.isSelected()) {
            role = "staff";
        } else if (eventOrganiserRadio.isSelected()) {
            role = "eventorganiser";
        }

        if (username.isEmpty() || password.isEmpty() || role.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return;
        }


        try {
            FileWriter writer = new FileWriter("src/data/users.txt", true);
            writer.write(username + "," + password + "," + role + "\n");
            writer.close();
            JOptionPane.showMessageDialog(this, "Sign-up successful!");
            GUIManager.getInstance().disposeWindow(this); 
            GUIManager.getInstance().showMainDashboard(); 
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving user.");
        }
    }
}