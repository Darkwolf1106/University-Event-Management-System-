package gui;


import facade.GUIManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;

public class RegisteredEventWindow extends JFrame {

    private JTextField nameField;
    private JTextField idField;
    private JButton submitButton;
    private JTextArea resultArea;
    private JButton backButton; 

    public RegisteredEventWindow() {
        setTitle("Check Registered Events");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); 
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10)); 


        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK); 
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); 

        JLabel headerLabel = new JLabel("VIEW REGISTERED EVENTS");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 36));
        headerLabel.setForeground(Color.WHITE); 
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH); 

       
        JPanel contentPanel = new JPanel(new GridBagLayout()); 
        contentPanel.setBackground(Color.WHITE); 
        contentPanel.setBorder(BorderFactory.createEmptyBorder(30, 200, 30, 200)); 
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); 
        gbc.fill = GridBagConstraints.HORIZONTAL; 

        Font labelFont = new Font("Arial", Font.PLAIN, 18);
        Font fieldFont = new Font("Arial", Font.PLAIN, 18);

      
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST;
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(labelFont);
        contentPanel.add(nameLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        nameField = new JTextField(20);
        nameField.setFont(fieldFont);
        contentPanel.add(nameField, gbc);


        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.EAST;
        JLabel idLabel = new JLabel("User ID:");
        idLabel.setFont(labelFont);
        contentPanel.add(idLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 1; gbc.anchor = GridBagConstraints.WEST;
        idField = new JTextField(20);
        idField.setFont(fieldFont);
        contentPanel.add(idField, gbc);


        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0)); 
        buttonPanel.setOpaque(false); 

        submitButton = new JButton("CHECK REGISTRATIONS");
        submitButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        submitButton.setBackground(new Color(70, 130, 180)); 
        submitButton.setForeground(Color.BLACK); 
        submitButton.setFocusPainted(false);
        submitButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 100, 150), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(submitButton);

        backButton = new JButton("BACK"); 
        backButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        backButton.setBackground(new Color(170, 180, 190)); 
        backButton.setForeground(Color.BLACK);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(120, 130, 140), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(backButton);

   
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 10, 20, 10); 
        contentPanel.add(buttonPanel, gbc);

        
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2; gbc.weighty = 1.0; 
        gbc.fill = GridBagConstraints.BOTH; 
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Monospaced", Font.PLAIN, 16)); 
        JScrollPane scrollPane = new JScrollPane(resultArea);
        contentPanel.add(scrollPane, gbc);

        add(contentPanel, BorderLayout.CENTER); 

        
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                checkRegistrations();
            }
        });


        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIManager.getInstance().disposeWindow(RegisteredEventWindow.this); 
                GUIManager.getInstance().showStudentStaffDashboard(); 
            }
        });
    }

    private void checkRegistrations() {
        String name = nameField.getText().trim();
        String id = idField.getText().trim();
        resultArea.setText(""); 

        if (name.isEmpty() || id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both name and ID.");
            return;
        }

        File file = new File("src/data/registrations.txt");
        if (!file.exists()) {
            resultArea.setText("No registration records found.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            boolean found = false;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 5) {
                    String regName = parts[0].trim();
                    String regId = parts[1].trim();
                    String eventName = parts[3].trim();

                    if (regName.equalsIgnoreCase(name) && regId.equals(id)) {
                        found = true;
                        resultArea.append("• " + eventName + "\n");
                    }
                }
            }

            if (!found) {
                resultArea.setText("No events registered for this user.");
            }
        } catch (IOException e) {
            resultArea.setText("Error reading registrations.txt.");
        }
    }
}
