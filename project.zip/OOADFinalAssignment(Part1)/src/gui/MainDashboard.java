package gui;


import facade.GUIManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL; 

public class MainDashboard extends JFrame {

    public MainDashboard() {
        setTitle("Campus Event System"); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK); 
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); 

        JLabel welcomeLabel = new JLabel("WELCOME TO CAMPUS EVENT SYSTEM !");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 36)); 
        welcomeLabel.setForeground(Color.WHITE); 
        headerPanel.add(welcomeLabel);
        add(headerPanel, BorderLayout.NORTH); 

        
        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20); 
        gbc.fill = GridBagConstraints.HORIZONTAL; 
        gbc.gridx = 0; 
        
       
        Color signUpOriginalBg = new Color(70, 130, 180); 
        Color signUpHoverBg = new Color(90, 150, 200); 
        Color loginOriginalBg = new Color(60, 179, 113); 
        Color loginHoverBg = new Color(80, 199, 133); 
        Color textColor = Color.BLACK;

      
        ImageIcon campusIcon = null;
        try {
            URL imageUrl = getClass().getClassLoader().getResource("mmulogo.png");
            if (imageUrl != null) {
                campusIcon = new ImageIcon(new ImageIcon(imageUrl).getImage().getScaledInstance(150, 200, Image.SCALE_SMOOTH));
            } else {
                System.err.println("mmulogo.png not found in resources folder. Using placeholder.");
                campusIcon = new ImageIcon(new ImageIcon("/Users/tharunnesh/NetBeansProjects/OOADFinalAssignment(Part1)/src/resources/mmulogo.png").getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH));
            }
        } catch (Exception e) {
            System.err.println("Error loading image: " + e.getMessage());
            campusIcon = new ImageIcon(new ImageIcon("/Users/tharunnesh/NetBeansProjects/OOADFinalAssignment(Part1)/src/resources/mmulogo.png").getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH));
        }
        
        JLabel imageLabel = new JLabel(campusIcon);
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER); 
        gbc.gridy = 0; 
        gbc.gridwidth = 1; 
        contentPanel.add(imageLabel, gbc);


        
        gbc.gridy = 1; 
        JButton signUpButton = new JButton("SIGN UP");
        signUpButton.setFont(new Font("SansSerif", Font.BOLD, 24)); 
        signUpButton.setBackground(signUpOriginalBg);
        signUpButton.setForeground(textColor);
        signUpButton.setFocusPainted(false); 
        signUpButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 100, 150), 2), 
            BorderFactory.createEmptyBorder(15, 30, 15, 30) 
        ));
        contentPanel.add(signUpButton, gbc);


        signUpButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                signUpButton.setBackground(signUpHoverBg);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                signUpButton.setBackground(signUpOriginalBg);
            }
        });


        gbc.gridy = 2; 
        JButton loginButton = new JButton("LOGIN");
        loginButton.setFont(new Font("SansSerif", Font.BOLD, 24)); 
        loginButton.setBackground(loginOriginalBg);
        loginButton.setForeground(textColor);
        loginButton.setFocusPainted(false); 
        loginButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(40, 120, 80), 2), 
            BorderFactory.createEmptyBorder(15, 30, 15, 30) 
        ));
        contentPanel.add(loginButton, gbc);


        loginButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                loginButton.setBackground(loginHoverBg);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                loginButton.setBackground(loginOriginalBg);
            }
        });

        add(contentPanel, BorderLayout.CENTER); 
    
        signUpButton.addActionListener(e -> GUIManager.getInstance().showSignUpWindow());

        loginButton.addActionListener(e -> GUIManager.getInstance().showLoginWindow());
    }
}