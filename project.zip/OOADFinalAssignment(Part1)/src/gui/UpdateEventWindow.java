package gui;

import facade.GUIManager;
import manager.EventManager;
import model.Event;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class UpdateEventWindow extends JFrame {
    private JComboBox<String> eventComboBox;
    private JTextField nameField, dateField, startTimeField, endTimeField, venueField, capacityField, feeField;
    private JComboBox<String> typeBox;
    private JCheckBox cateringBox, transportBox;
    private JCheckBox earlyBirdBox, staffBox;
    private JButton updateButton;
    private ArrayList<Event> events;
    private JButton backButton; 

    public UpdateEventWindow() {
        setTitle("Update Event");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); 
        setLocationRelativeTo(null);
        setLayout(new BorderLayout()); 

        
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK); 
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); 
        
        JLabel headerLabel = new JLabel("UPDATE EVENT DETAILS");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 36)); 
        headerLabel.setForeground(Color.WHITE); 
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridLayout(11, 2, 10, 10)); 
        formPanel.setBackground(Color.WHITE); 
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 200, 30, 200)); 

        Font labelFont = new Font("Arial", Font.PLAIN, 18);
        Font fieldFont = new Font("Arial", Font.PLAIN, 18);
        Font dropdownFont = new Font("Arial", Font.PLAIN, 18);
        Font checkboxFont = new Font("Arial", Font.PLAIN, 16);

        events = EventManager.getInstance().getEvents();
        eventComboBox = new JComboBox<>();
        eventComboBox.setFont(dropdownFont); 
        for (Event e : events) {
            eventComboBox.addItem(e.getName() + " (" + e.getDate() + ")");
        }

        nameField = new JTextField();
        dateField = new JTextField();
        startTimeField = new JTextField();
        endTimeField = new JTextField();
        venueField = new JTextField();
        capacityField = new JTextField();
        feeField = new JTextField();
        typeBox = new JComboBox<>(new String[]{"Seminar", "Workshop", "Cultural Event", "Sports Event"});
        cateringBox = new JCheckBox("Catering (RM10)");
        transportBox = new JCheckBox("Transportation (RM10)");
        earlyBirdBox = new JCheckBox("Early Bird Discount (20%)");
        staffBox = new JCheckBox("Staff Discount (5%)");

        nameField.setFont(fieldFont);
        dateField.setFont(fieldFont);
        startTimeField.setFont(fieldFont);
        endTimeField.setFont(fieldFont);
        venueField.setFont(fieldFont);
        capacityField.setFont(fieldFont);
        feeField.setFont(fieldFont);
        typeBox.setFont(dropdownFont);
        cateringBox.setFont(checkboxFont);
        transportBox.setFont(checkboxFont);
        earlyBirdBox.setFont(checkboxFont);
        staffBox.setFont(checkboxFont);

        cateringBox.setOpaque(false);
        transportBox.setOpaque(false);
        earlyBirdBox.setOpaque(false);
        staffBox.setOpaque(false);

        JLabel selectEventLabel = new JLabel("Select Event:");
        selectEventLabel.setFont(labelFont);
        formPanel.add(selectEventLabel);
        formPanel.add(eventComboBox);

        JLabel nameLabel = new JLabel("Event Name:");
        nameLabel.setFont(labelFont);
        formPanel.add(nameLabel);
        formPanel.add(nameField);

        JLabel dateLabel = new JLabel("Date (DD-MM-YYYY):");
        dateLabel.setFont(labelFont);
        formPanel.add(dateLabel);
        formPanel.add(dateField);

        JLabel startTimeLabel = new JLabel("Start Time (hh:mm AM/PM):");
        startTimeLabel.setFont(labelFont);
        formPanel.add(startTimeLabel);
        formPanel.add(startTimeField);

        JLabel endTimeLabel = new JLabel("End Time (hh:mm AM/PM):");
        endTimeLabel.setFont(labelFont);
        formPanel.add(endTimeLabel);
        formPanel.add(endTimeField);

        JLabel venueLabel = new JLabel("Venue:");
        venueLabel.setFont(labelFont);
        formPanel.add(venueLabel);
        formPanel.add(venueField);

        JLabel typeLabel = new JLabel("Type:");
        typeLabel.setFont(labelFont);
        formPanel.add(typeLabel);
        formPanel.add(typeBox);

        JLabel capacityLabel = new JLabel("Capacity:");
        capacityLabel.setFont(labelFont);
        formPanel.add(capacityLabel);
        formPanel.add(capacityField);

        JLabel feeLabel = new JLabel("Registration Fee (RM, optional):");
        feeLabel.setFont(labelFont);
        formPanel.add(feeLabel);
        formPanel.add(feeField);

        JLabel servicesLabel = new JLabel("Optional Services (each RM10):");
        servicesLabel.setFont(labelFont);
        formPanel.add(servicesLabel);
        JPanel servicesPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        servicesPanel.setOpaque(false);
        servicesPanel.add(cateringBox);
        servicesPanel.add(transportBox);
        formPanel.add(servicesPanel);

        JLabel discountsLabel = new JLabel("Discounts:");
        discountsLabel.setFont(labelFont);
        formPanel.add(discountsLabel);
        JPanel discountPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        discountPanel.setOpaque(false); 
        discountPanel.add(earlyBirdBox);
        discountPanel.add(staffBox);
        formPanel.add(discountPanel);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false); 

        updateButton = new JButton("UPDATE EVENT");
        updateButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        updateButton.setBackground(new Color(60, 179, 113)); 
        updateButton.setForeground(Color.BLACK); 
        updateButton.setFocusPainted(false);
        updateButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(40, 120, 80), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(updateButton);

        backButton = new JButton("BACK"); 
        backButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        backButton.setBackground(new Color(170, 180, 190)); 
        backButton.setForeground(Color.BLACK);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(120, 130, 140), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(backButton); 


        JPanel outerPanel = new JPanel(new BorderLayout());
        outerPanel.setOpaque(false); 
        outerPanel.add(formPanel, BorderLayout.CENTER);
        outerPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(outerPanel, BorderLayout.CENTER);

        eventComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadSelectedEvent();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateEvent();
            }
        });

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIManager.getInstance().disposeWindow(UpdateEventWindow.this); 
                GUIManager.getInstance().showEventOrganiserDashboard(); 
            }
        });

        if (events.size() > 0) {
            eventComboBox.setSelectedIndex(0);
            loadSelectedEvent();
        }
    }

    private void loadSelectedEvent() {
        int idx = eventComboBox.getSelectedIndex();
        if (idx < 0) return;
        Event event = events.get(idx);
        nameField.setText(event.getName());
        dateField.setText(event.getDate());
        startTimeField.setText(event.getStartTime());
        endTimeField.setText(event.getEndTime());
        venueField.setText(event.getVenue());
        typeBox.setSelectedItem(event.getType());
        capacityField.setText(String.valueOf(event.getCapacity()));
        feeField.setText(String.valueOf(event.getRegistrationFee()));
        cateringBox.setSelected(event.getOptionalServices().contains("Catering"));
        transportBox.setSelected(event.getOptionalServices().contains("Transportation"));
        earlyBirdBox.setSelected(event.hasEarlyBirdDiscount());
        staffBox.setSelected(event.hasStaffDiscount());
    }

    private void updateEvent() {
        int idx = eventComboBox.getSelectedIndex();
        if (idx < 0) return;
        String name = nameField.getText().trim();
        String date = dateField.getText().trim();
        String startTime = startTimeField.getText().trim();
        String endTime = endTimeField.getText().trim();

        if (!date.matches("\\d{2}-\\d{2}-\\d{4}")) {
            JOptionPane.showMessageDialog(this, "Date must be in DD-MM-YYYY format.");
            return;
        }
        if (!startTime.matches("((0[1-9])|(1[0-2])):[0-5][0-9] [APap][Mm]")) {
            JOptionPane.showMessageDialog(this, "Start Time must be in hh:mm AM/PM format (e.g., 02:30 PM).");
            return;
        }
        if (!endTime.matches("((0[1-9])|(1[0-2])):[0-5][0-9] [APap][Mm]")) {
            JOptionPane.showMessageDialog(this, "End Time must be in hh:mm AM/PM format (e.g., 05:00 PM).");
            return;
        }

        String venue = venueField.getText().trim();
        String type = (String) typeBox.getSelectedItem();
        int capacity;
        double fee = 0.0;
        try {
            capacity = Integer.parseInt(capacityField.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid capacity.");
            return;
        }
        try {
            String feeText = feeField.getText().trim();
            fee = feeText.isEmpty() ? 0.0 : Double.parseDouble(feeText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid fee.");
            return;
        }
        ArrayList<String> services = new ArrayList<>();
        if (cateringBox.isSelected()) services.add("Catering");
        if (transportBox.isSelected()) services.add("Transportation");

        if (name.isEmpty() || date.isEmpty() || startTime.isEmpty() || endTime.isEmpty() || venue.isEmpty() || type.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all required fields.");
            return;
        }

        boolean earlyBird = earlyBirdBox.isSelected();
        boolean staff = staffBox.isSelected();
        Event updatedEvent = new Event(name, date, startTime, endTime, venue, type, capacity, fee, services, earlyBird, staff);
        EventManager.getInstance().updateEvent(idx, updatedEvent);
        JOptionPane.showMessageDialog(this, "Event updated successfully!");
        GUIManager.getInstance().disposeWindow(this); 
        GUIManager.getInstance().showEventOrganiserDashboard(); 
    }
}