package gui;


import facade.GUIManager;
import manager.EventManager;
import model.Event;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class AddEventWindow extends JFrame {
    private JTextField nameField, dateField, startTimeField, endTimeField, venueField, capacityField, feeField;
    private JComboBox<String> typeBox;
    private JCheckBox cateringBox, transportBox;
    private JButton addButton;
    private JCheckBox earlyBirdBox, staffBox;
    private JButton backButton; 

    public AddEventWindow() {
        setTitle("Add Event");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); 
        setLocationRelativeTo(null);
        setLayout(new BorderLayout()); 

        // --- Header Panel ---
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK); 
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); 

        JLabel headerLabel = new JLabel("ADD NEW EVENT");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 36)); 
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH); 

        // --- Main Content Panel (Form Area) ---
        JPanel formPanel = new JPanel(new GridLayout(10, 2, 10, 10)); 
        formPanel.setBackground(Color.WHITE); // Light blue background
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 200, 30, 200)); 

        Font labelFont = new Font("Arial", Font.PLAIN, 18);
        Font fieldFont = new Font("Arial", Font.PLAIN, 18);
        Font checkboxFont = new Font("Arial", Font.PLAIN, 16);

        nameField = new JTextField();
        dateField = new JTextField();
        startTimeField = new JTextField();
        endTimeField = new JTextField();
        venueField = new JTextField();
        capacityField = new JTextField();
        feeField = new JTextField();
        typeBox = new JComboBox<>(new String[]{"Seminar", "Workshop", "Cultural Event", "Sports Event"});
        cateringBox = new JCheckBox("Catering (RM10)");
        transportBox = new JCheckBox("Transportation (RM10)");
        earlyBirdBox = new JCheckBox("Early Bird Discount (20%)");
        staffBox = new JCheckBox("Staff Discount (5%)");

        
        nameField.setFont(fieldFont);
        dateField.setFont(fieldFont);
        startTimeField.setFont(fieldFont);
        endTimeField.setFont(fieldFont);
        venueField.setFont(fieldFont);
        capacityField.setFont(fieldFont);
        feeField.setFont(fieldFont);
        typeBox.setFont(fieldFont);
        cateringBox.setFont(checkboxFont);
        transportBox.setFont(checkboxFont);
        earlyBirdBox.setFont(checkboxFont);
        staffBox.setFont(checkboxFont);

      
        cateringBox.setOpaque(false);
        transportBox.setOpaque(false);
        earlyBirdBox.setOpaque(false);
        staffBox.setOpaque(false);


        
        JLabel nameLabel = new JLabel("Event Name:");
        nameLabel.setFont(labelFont);
        formPanel.add(nameLabel);
        formPanel.add(nameField);

        JLabel dateLabel = new JLabel("Date (DD-MM-YYYY):");
        dateLabel.setFont(labelFont);
        formPanel.add(dateLabel);
        formPanel.add(dateField);

        JLabel startTimeLabel = new JLabel("Start Time (hh:mm AM/PM):");
        startTimeLabel.setFont(labelFont);
        formPanel.add(startTimeLabel);
        formPanel.add(startTimeField);

        JLabel endTimeLabel = new JLabel("End Time (hh:mm AM/PM):");
        endTimeLabel.setFont(labelFont);
        formPanel.add(endTimeLabel);
        formPanel.add(endTimeField);

        JLabel venueLabel = new JLabel("Venue:");
        venueLabel.setFont(labelFont);
        formPanel.add(venueLabel);
        formPanel.add(venueField);

        JLabel typeLabel = new JLabel("Type:");
        typeLabel.setFont(labelFont);
        formPanel.add(typeLabel);
        formPanel.add(typeBox);

        JLabel capacityLabel = new JLabel("Capacity:");
        capacityLabel.setFont(labelFont);
        formPanel.add(capacityLabel);
        formPanel.add(capacityField);

        JLabel feeLabel = new JLabel("Registration Fee (RM, optional):");
        feeLabel.setFont(labelFont);
        formPanel.add(feeLabel);
        formPanel.add(feeField);

        JLabel servicesLabel = new JLabel("Optional Services (each RM10):");
        servicesLabel.setFont(labelFont);
        formPanel.add(servicesLabel);
        JPanel servicesPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        servicesPanel.setOpaque(false); 
        servicesPanel.add(cateringBox);
        servicesPanel.add(transportBox);
        formPanel.add(servicesPanel);

        JLabel discountsLabel = new JLabel("Discounts:");
        discountsLabel.setFont(labelFont);
        formPanel.add(discountsLabel);
        JPanel discountPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        discountPanel.setOpaque(false); 
        discountPanel.add(earlyBirdBox);
        discountPanel.add(staffBox);
        formPanel.add(discountPanel);

         
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false); // Make transparent

        addButton = new JButton("ADD EVENT");
        addButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        addButton.setBackground(new Color(70, 130, 180)); 
        addButton.setForeground(Color.BLACK); 
        addButton.setFocusPainted(false);
        addButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 100, 150), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(addButton);

        backButton = new JButton("BACK"); 
        backButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        backButton.setBackground(new Color(170, 180, 190)); 
        backButton.setForeground(Color.BLACK);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(120, 130, 140), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(backButton); 


        JPanel outerPanel = new JPanel(new BorderLayout());
        outerPanel.setOpaque(false); 
        outerPanel.add(formPanel, BorderLayout.CENTER);
        outerPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(outerPanel, BorderLayout.CENTER);

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addEvent();
            }
        });

       
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIManager.getInstance().disposeWindow(AddEventWindow.this); 
                GUIManager.getInstance().showEventOrganiserDashboard();
            }
        });

        
    }

    private void addEvent() {
        String name = nameField.getText().trim();
        String date = dateField.getText().trim();
        String startTime = startTimeField.getText().trim();
        String endTime = endTimeField.getText().trim();

       
        if (!date.matches("\\d{2}-\\d{2}-\\d{4}")) {
            JOptionPane.showMessageDialog(this, "Date must be in DD-MM-YYYY format.");
            return;
        }
      
        if (!startTime.matches("((0[1-9])|(1[0-2])):[0-5][0-9] [APap][Mm]")) {
            JOptionPane.showMessageDialog(this, "Start Time must be in hh:mm AM/PM format (e.g., 02:30 PM).");
            return;
        }
        if (!endTime.matches("((0[1-9])|(1[0-2])):[0-5][0-9] [APap][Mm]")) {
            JOptionPane.showMessageDialog(this, "End Time must be in hh:mm AM/PM format (e.g., 05:00 PM).");
            return;
        }
        String venue = venueField.getText().trim();
        String type = (String) typeBox.getSelectedItem();
        int capacity;
        double fee = 0.0;
        try {
            capacity = Integer.parseInt(capacityField.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid capacity.");
            return;
        }
        try {
            String feeText = feeField.getText().trim();
            fee = feeText.isEmpty() ? 0.0 : Double.parseDouble(feeText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid fee.");
            return;
        }
        ArrayList<String> services = new ArrayList<>();
        if (cateringBox.isSelected()) services.add("Catering");
        if (transportBox.isSelected()) services.add("Transportation");

        if (name.isEmpty() || date.isEmpty() || startTime.isEmpty() || endTime.isEmpty() || venue.isEmpty() || type.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all required fields.");
            return;
        }

        boolean earlyBird = earlyBirdBox.isSelected();
        boolean staff = staffBox.isSelected();
        Event event = new Event(name, date, startTime, endTime, venue, type, capacity, fee, services, earlyBird, staff);
        EventManager.getInstance().addEvent(event);
        JOptionPane.showMessageDialog(this, "Event added successfully!");
        GUIManager.getInstance().disposeWindow(this); 
        GUIManager.getInstance().showEventOrganiserDashboard(); 
    }
}
