package gui;

import facade.GUIManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class StudentStaffDashboard extends JFrame {
    private JTextArea eventDisplayArea;
    private JButton logOutButton; 

    public StudentStaffDashboard() {
        setTitle("Student/Staff Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); 
        setLocationRelativeTo(null);
        setLayout(new BorderLayout()); 
        
  
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK); 
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); 

        JLabel heading = new JLabel("WELCOME STUDENT/STAFF");
        heading.setFont(new Font("Arial", Font.BOLD, 36)); 
        heading.setForeground(Color.WHITE); 
        headerPanel.add(heading);
        add(headerPanel, BorderLayout.NORTH); 

        JPanel contentPanel = new JPanel(new GridBagLayout()); 
        contentPanel.setBackground(Color.WHITE); 
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50)); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); 
        gbc.fill = GridBagConstraints.BOTH; 
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;

        eventDisplayArea = new JTextArea();
        eventDisplayArea.setEditable(false);
        eventDisplayArea.setFont(new Font("Monospaced", Font.PLAIN, 16)); 
        JScrollPane scrollPane = new JScrollPane(eventDisplayArea);
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4; 
        gbc.weighty = 0.8; 
        contentPanel.add(scrollPane, gbc);

        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 20)); 
        buttonPanel.setOpaque(false); 

        JButton viewEventsButton = new JButton("VIEW EVENTS");
        JButton eventRegistrationButton = new JButton("EVENT REGISTRATION");
        JButton registeredEventsButton = new JButton("REGISTERED EVENTS");
        JButton billButton = new JButton("BILL");
        logOutButton = new JButton("LOG OUT");


        Font buttonFont = new Font("SansSerif", Font.BOLD, 20);
        Color primaryBg = new Color(70, 130, 180); 
        Color secondaryBg = new Color(60, 179, 113); 
        Color neutralBg = new Color(170, 180, 190);
        Color textColor = Color.BLACK;

        viewEventsButton.setFont(buttonFont);
        viewEventsButton.setBackground(primaryBg);
        viewEventsButton.setForeground(textColor);
        viewEventsButton.setFocusPainted(false);
        viewEventsButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 100, 150), 2),
            BorderFactory.createEmptyBorder(12, 25, 12, 25)
        ));

        eventRegistrationButton.setFont(buttonFont);
        eventRegistrationButton.setBackground(secondaryBg);
        eventRegistrationButton.setForeground(textColor);
        eventRegistrationButton.setFocusPainted(false);
        eventRegistrationButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(40, 120, 80), 2),
            BorderFactory.createEmptyBorder(12, 25, 12, 25)
        ));

        registeredEventsButton.setFont(buttonFont);
        registeredEventsButton.setBackground(primaryBg);
        registeredEventsButton.setForeground(textColor);
        registeredEventsButton.setFocusPainted(false);
        registeredEventsButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 100, 150), 2),
            BorderFactory.createEmptyBorder(12, 25, 12, 25)
        ));

        billButton.setFont(buttonFont);
        billButton.setBackground(secondaryBg);
        billButton.setForeground(textColor);
        billButton.setFocusPainted(false);
        billButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(40, 120, 80), 2),
            BorderFactory.createEmptyBorder(12, 25, 12, 25)
        ));

        logOutButton.setFont(buttonFont);
        logOutButton.setBackground(neutralBg); 
        logOutButton.setForeground(textColor);
        logOutButton.setFocusPainted(false);
        logOutButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(120, 130, 140), 2),
            BorderFactory.createEmptyBorder(12, 25, 12, 25)
        ));


        buttonPanel.add(viewEventsButton);
        buttonPanel.add(eventRegistrationButton);
        buttonPanel.add(registeredEventsButton);
        buttonPanel.add(billButton);
        buttonPanel.add(logOutButton); 

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 4; 
        gbc.weighty = 0.2; 
        contentPanel.add(buttonPanel, gbc);

        add(contentPanel, BorderLayout.CENTER); 

        viewEventsButton.addActionListener(e -> loadEventsFromFile());

        eventRegistrationButton.addActionListener(e -> GUIManager.getInstance().showEventRegistrationWindow());

        registeredEventsButton.addActionListener(e -> GUIManager.getInstance().showRegisteredEventWindow());

        billButton.addActionListener(e -> GUIManager.getInstance().showBillWindow());

        logOutButton.addActionListener(e -> {
            GUIManager.getInstance().disposeWindow(StudentStaffDashboard.this); 
            GUIManager.getInstance().showMainDashboard();
        });

    }

    private void loadEventsFromFile() {
        eventDisplayArea.setText("");
        File file = new File("src/data/events.txt");

        if (!file.exists()) {
            eventDisplayArea.setText("No events found.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int count = 1;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 8) {
                    String output = count++ + ". " +
                            "Name: " + parts[0] + "\n   " +
                            "Date: " + parts[1] + "\n   " +
                            "Start Time: " + parts[2] + "\n   " +
                            "End Time: " + parts[3] + "\n   " +
                            "Venue: " + parts[4] + "\n   " +
                            "Fee: RM" + parts[7] + "\n\n";
                    eventDisplayArea.append(output);
                }
            }
        } catch (IOException e) {
            eventDisplayArea.setText("Error reading events.txt.");
        }
    }
}