package gui;


import facade.GUIManager;
import javax.swing.*;
import java.awt.*;


public class EventOrganiserDashboard extends JFrame {
    private JButton logOutButton; 

    public EventOrganiserDashboard() {
        setTitle("Event Organiser Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        
      
        setLayout(new BorderLayout());

        // --- Header Panel ---
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK); 
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); 

        JLabel headerLabel = new JLabel("EVENT ORGANISER DASHBOARD");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 36)); 
        headerLabel.setForeground(Color.WHITE); 
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH); 

        // --- Main Content Panel (Buttons Area) ---
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 40, 40)); 
        buttonPanel.setBackground(Color.WHITE); 
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(100, 200, 100, 200));

        JButton addEventButton = new JButton("ADD EVENT");
        JButton updateEventButton = new JButton("UPDATE EVENT");
        JButton cancelEventButton = new JButton("CANCEL EVENT");
        JButton viewAttendeesButton = new JButton("VIEW ATENDEES");
        logOutButton = new JButton("LOG OUT"); 

        
        Font buttonFont = new Font("SansSerif", Font.BOLD, 24); 
        Color primaryBg = new Color(70, 130, 180);
        Color secondaryBg = new Color(60, 179, 113); 
        Color neutralBg = new Color(170, 180, 190); 
        Color textColor = Color.BLACK;

        addEventButton.setFont(buttonFont);
        addEventButton.setBackground(primaryBg);
        addEventButton.setForeground(textColor);
        addEventButton.setFocusPainted(false);
        addEventButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 100, 150), 2), 
            BorderFactory.createEmptyBorder(15, 30, 15, 30) 
        ));

       
        updateEventButton.setFont(buttonFont);
        updateEventButton.setBackground(secondaryBg); 
        updateEventButton.setForeground(textColor);
        updateEventButton.setFocusPainted(false);
        updateEventButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(40, 120, 80), 2), 
            BorderFactory.createEmptyBorder(15, 30, 15, 30) 
        ));

        
        cancelEventButton.setFont(buttonFont);
        cancelEventButton.setBackground(primaryBg); 
        cancelEventButton.setForeground(textColor);
        cancelEventButton.setFocusPainted(false);
        cancelEventButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 100, 150), 2), 
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));

       
        viewAttendeesButton.setFont(buttonFont);
        viewAttendeesButton.setBackground(secondaryBg); 
        viewAttendeesButton.setForeground(textColor);
        viewAttendeesButton.setFocusPainted(false);
        viewAttendeesButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(40, 120, 80), 2), 
            BorderFactory.createEmptyBorder(15, 30, 15, 30) 
        ));

        
        logOutButton.setFont(buttonFont);
        logOutButton.setBackground(neutralBg);
        logOutButton.setForeground(textColor);
        logOutButton.setFocusPainted(false);
        logOutButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(120, 130, 140), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));

        buttonPanel.add(addEventButton);
        buttonPanel.add(updateEventButton);
        buttonPanel.add(cancelEventButton);
        buttonPanel.add(viewAttendeesButton);
        buttonPanel.add(logOutButton); 

        add(buttonPanel, BorderLayout.CENTER); 

       
        addEventButton.addActionListener(e -> GUIManager.getInstance().showAddEventWindow());
        updateEventButton.addActionListener(e -> GUIManager.getInstance().showUpdateEventWindow());
        cancelEventButton.addActionListener(e -> GUIManager.getInstance().showCancelEventWindow());
        viewAttendeesButton.addActionListener(e -> GUIManager.getInstance().showViewAttendeesWindow());

        
        logOutButton.addActionListener(e -> {
            GUIManager.getInstance().disposeWindow(EventOrganiserDashboard.this); 
            GUIManager.getInstance().showMainDashboard(); 
        });

        
    }
}
