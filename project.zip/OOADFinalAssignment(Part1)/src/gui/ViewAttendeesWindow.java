package gui;

import facade.GUIManager;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.Vector;

public class ViewAttendeesWindow extends JFrame {
    private JButton backButton; 

    public ViewAttendeesWindow() {
        setTitle("View Attendees");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); 
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10)); 
        
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK); 
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); 
        
        JLabel headerLabel = new JLabel("VIEW REGISTERED ATTENDEES");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 36)); 
        headerLabel.setForeground(Color.WHITE); 
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH); 

        JPanel contentPanel = new JPanel(new BorderLayout()); 
        contentPanel.setBackground(Color.WHITE); 
        contentPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50)); 

        String[] columnNames = {"Name", "ID", "Role", "Registered Event"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        try (BufferedReader reader = new BufferedReader(new FileReader("src/data/registrations.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 4) {
                    Vector<String> row = new Vector<>();
                    row.add(parts[0].trim()); 
                    row.add(parts[1].trim()); 
                    row.add(parts[2].trim()); 
                    row.add(parts[3].trim()); 
                    model.addRow(row);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading registrations.txt.");
        }

        JTable table = new JTable(model);
        table.setFont(new Font("Arial", Font.PLAIN, 16)); 
        table.setRowHeight(25); 
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 18)); 
        table.getTableHeader().setBackground(new Color(100, 149, 237)); 
        table.getTableHeader().setForeground(Color.WHITE); 

        JScrollPane scrollPane = new JScrollPane(table);
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0)); 
        buttonPanel.setOpaque(false); 

        backButton = new JButton("BACK"); 
        backButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        backButton.setBackground(new Color(170, 180, 190)); 
        backButton.setForeground(Color.BLACK);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(120, 130, 140), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(backButton); 
        contentPanel.add(buttonPanel, BorderLayout.SOUTH); 

        add(contentPanel, BorderLayout.CENTER); 

        backButton.addActionListener(e -> {
            GUIManager.getInstance().disposeWindow(ViewAttendeesWindow.this); 
            GUIManager.getInstance().showEventOrganiserDashboard(); 
        });
    }
}