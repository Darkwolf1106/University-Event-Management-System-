package gui;


import facade.GUIManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class BillWindow extends JFrame {
    private JTextField nameField;
    private JTextField idField;
    private JButton calculateButton;
    private JTextArea billArea;
    private JButton backButton; 

    public BillWindow() {
        setTitle("Calculate Bill");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); 
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10)); 

        // --- Header Panel ---
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK); 
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); 

        JLabel headerLabel = new JLabel("CALCULATE BILL");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 36)); 
        headerLabel.setForeground(Color.WHITE); 
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH); 

        // --- Main Content Panel (Input and Result Area) ---
        JPanel contentPanel = new JPanel(new GridBagLayout()); 
        contentPanel.setBackground(Color.WHITE); 
        contentPanel.setBorder(BorderFactory.createEmptyBorder(30, 200, 30, 200)); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL; 

        Font labelFont = new Font("Arial", Font.PLAIN, 18);
        Font fieldFont = new Font("Arial", Font.PLAIN, 18);

        // Name
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST;
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(labelFont);
        contentPanel.add(nameLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        nameField = new JTextField(20);
        nameField.setFont(fieldFont);
        contentPanel.add(nameField, gbc);

        // ID
        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.EAST;
        JLabel idLabel = new JLabel("User ID:");
        idLabel.setFont(labelFont);
        contentPanel.add(idLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 1; gbc.anchor = GridBagConstraints.WEST;
        idField = new JTextField(20);
        idField.setFont(fieldFont);
        contentPanel.add(idField, gbc);

        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0)); 
        buttonPanel.setOpaque(false); 

        calculateButton = new JButton("CALCULATE BILL");
        calculateButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        calculateButton.setBackground(new Color(60, 179, 113)); 
        calculateButton.setForeground(Color.BLACK); 
        calculateButton.setFocusPainted(false);
        calculateButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(40, 120, 80), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(calculateButton);

        backButton = new JButton("BACK"); 
        backButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        backButton.setBackground(new Color(170, 180, 190)); 
        backButton.setForeground(Color.BLACK);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(120, 130, 140), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(backButton); 

       
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 10, 20, 10); 
        contentPanel.add(buttonPanel, gbc);

        // Bill Area
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2; gbc.weighty = 1.0; 
        gbc.fill = GridBagConstraints.BOTH; 
        billArea = new JTextArea();
        billArea.setEditable(false);
        billArea.setFont(new Font("Monospaced", Font.PLAIN, 16)); 
        JScrollPane scrollPane = new JScrollPane(billArea);
        contentPanel.add(scrollPane, gbc);

        add(contentPanel, BorderLayout.CENTER); 

        calculateButton.addActionListener(e -> calculateBill());

        
        backButton.addActionListener(e -> {
            GUIManager.getInstance().disposeWindow(BillWindow.this);
            GUIManager.getInstance().showStudentStaffDashboard(); 
        });

       
    }

    private void calculateBill() {
        String name = nameField.getText().trim();
        String id = idField.getText().trim();
        billArea.setText("");

        if (name.isEmpty() || id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both name and ID.");
            return;
        }

        
        class EventInfo {
            double fee;
            boolean earlyBird;
            boolean staffDiscount;
        }

        Map<String, EventInfo> eventMap = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("src/data/events.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 11) {
                    EventInfo info = new EventInfo();
                    info.fee = Double.parseDouble(parts[7].trim());
                    info.earlyBird = parts[9].trim().equalsIgnoreCase("true");
                    info.staffDiscount = parts[10].trim().equalsIgnoreCase("true");
                    eventMap.put(parts[0].trim(), info);
                }
            }
        } catch (IOException | NumberFormatException e) {
            billArea.setText("Error reading events.txt.");
            return;
        }

        
        Map<String, java.util.List<String[]>> registrationsByEvent = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("src/data/registrations.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 6) {
                    String event = parts[3].trim();
                    registrationsByEvent.putIfAbsent(event, new ArrayList<>());
                    registrationsByEvent.get(event).add(parts);
                }
            }
        } catch (IOException e) {
            billArea.setText("Error reading registrations.txt.");
            return;
        }

       
        double grandTotal = 0;
        StringBuilder result = new StringBuilder("Bill Details:\n\n");

        for (Map.Entry<String, java.util.List<String[]>> entry : registrationsByEvent.entrySet()) {
            String event = entry.getKey();
            java.util.List<String[]> registrations = entry.getValue();

            for (int i = 0; i < registrations.size(); i++) {
                String[] reg = registrations.get(i);
                String regName = reg[0].trim();
                String regId = reg[1].trim();
                String discountStatus = reg[4].trim();
                String addOns = reg[5].trim();

                if (regName.equalsIgnoreCase(name) && regId.equals(id)) {
                    EventInfo info = eventMap.getOrDefault(event, new EventInfo());
                    double baseFee = info.fee;
                    double addonFee = 0.0;

                    if (!addOns.equalsIgnoreCase("None")) {
                        addonFee = addOns.split("\\|").length * 10.0;
                    }

                    double total = baseFee + addonFee;

                  
                    if (info.staffDiscount && discountStatus.equalsIgnoreCase("Apply Staff Discount")) {
                        total *= 0.95;
                    }

                    
                    boolean isEarlyBird = info.earlyBird && (i < 10);
                    if (isEarlyBird) {
                        total *= 0.80;
                    }

                  
                    result.append("• Event: ").append(event);
                    if (isEarlyBird) result.append(" (Early Bird)");
                    result.append("\n");

                    result.append("  Base Fee: RM").append(String.format("%.2f", baseFee)).append("\n");
                    result.append("  Add-ons: \").append(addOns).append(\" (RM").append(String.format("%.2f", addonFee)).append(")\n");
                    result.append("  Staff Discount Applied: ").append((info.staffDiscount && discountStatus.equalsIgnoreCase("Apply Staff Discount")) ? "Yes" : "No").append("\n");
                    result.append("  Early Bird Applied: ").append(isEarlyBird ? "Yes" : "No").append("\n");
                    result.append("  Total for Event: RM").append(String.format("%.2f", total)).append("\n\n");

                    grandTotal += total;
                }
            }
        }

        if (grandTotal == 0) {
            billArea.setText("No matching registrations found for this user.");
        } else {
            result.append("Final Total for All Events: RM").append(String.format("%.2f", grandTotal));
            billArea.setText(result.toString());
        }
    }
}
