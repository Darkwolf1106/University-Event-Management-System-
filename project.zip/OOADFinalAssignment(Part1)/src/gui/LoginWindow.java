package gui;


import facade.GUIManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Scanner;


public class LoginWindow extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton backButton; 

    public LoginWindow() {
        setTitle("Login Page");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK); 
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); 

        JLabel headerLabel = new JLabel("LOGIN TO YOUR ACCOUNT");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 36)); 
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH); 

       
        JPanel contentPanel = new JPanel(new GridBagLayout()); 
        contentPanel.setBackground(Color.WHITE); 
        contentPanel.setBorder(BorderFactory.createEmptyBorder(50, 200, 50, 200)); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 10, 15, 10); 
        gbc.fill = GridBagConstraints.HORIZONTAL;

       
        gbc.gridx = 0; 
        gbc.gridy = 0; 
        gbc.anchor = GridBagConstraints.EAST; 
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        contentPanel.add(usernameLabel, gbc);

        gbc.gridx = 1; 
        gbc.gridy = 0; 
        gbc.anchor = GridBagConstraints.WEST; 
        usernameField = new JTextField(20); 
        usernameField.setFont(new Font("Arial", Font.PLAIN, 18));
        contentPanel.add(usernameField, gbc);

       
        gbc.gridx = 0; 
        gbc.gridy = 1; 
        gbc.anchor = GridBagConstraints.EAST;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        contentPanel.add(passwordLabel, gbc);

        gbc.gridx = 1; 
        gbc.gridy = 1; 
        gbc.anchor = GridBagConstraints.WEST;
        passwordField = new JPasswordField(20); 
        passwordField.setFont(new Font("Arial", Font.PLAIN, 18));
        contentPanel.add(passwordField, gbc);

       
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0)); 
        buttonPanel.setOpaque(false);

        loginButton = new JButton("LOGIN");
        loginButton.setFont(new Font("SansSerif", Font.BOLD, 24)); 
        loginButton.setBackground(new Color(60, 179, 113)); 
        loginButton.setForeground(Color.BLACK); 
        loginButton.setFocusPainted(false); 
        loginButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(40, 120, 80), 2), 
            BorderFactory.createEmptyBorder(15, 30, 15, 30) 
        ));
        buttonPanel.add(loginButton);

        backButton = new JButton("BACK"); 
        backButton.setFont(new Font("SansSerif", Font.BOLD, 24));
        backButton.setBackground(new Color(170, 180, 190)); 
        backButton.setForeground(Color.BLACK);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(120, 130, 140), 2),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        buttonPanel.add(backButton); 

        
        add(contentPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleLogin();
            }
        });


        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIManager.getInstance().disposeWindow(LoginWindow.this); 
                GUIManager.getInstance().showMainDashboard(); 
            }
        });
    }
    

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return;
        }

        boolean found = false;

        try {
            File file = new File("src/data/users.txt");
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");

                if (parts.length == 3) {
                    String savedUser = parts[0];
                    String savedPass = parts[1];
                    String role = parts[2];

                    if (username.equals(savedUser) && password.equals(savedPass)) {
                        found = true;
                        JOptionPane.showMessageDialog(this, "Login successful!");

                        if (role.equals("student") || role.equals("staff")) {
                            GUIManager.getInstance().showStudentStaffDashboard();
                        } else if (role.equals("eventorganiser")) {
                            GUIManager.getInstance().showEventOrganiserDashboard();
                        }
                        GUIManager.getInstance().disposeWindow(this);
                        break;
                    }
                }
            }

            scanner.close();

            if (!found) {
                JOptionPane.showMessageDialog(this, "Incorrect username or password.");
            }

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error reading users.txt.");
        }
    }
}