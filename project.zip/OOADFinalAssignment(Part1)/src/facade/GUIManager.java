package facade;


import gui.AddEventWindow;
import gui.BillWindow;
import gui.CancelEventWindow;
import gui.EventOrganiserDashboard;
import gui.EventRegistrationWindow;
import gui.LoginWindow;
import gui.MainDashboard;
import gui.RegisteredEventWindow;
import gui.SignUpWindow;
import gui.StudentStaffDashboard;
import gui.UpdateEventWindow;
import gui.ViewAttendeesWindow;
import javax.swing.JFrame; 

public class GUIManager {
    
    private static GUIManager instance;

  
    private GUIManager() {
        
    }


    public static GUIManager getInstance() {
        if (instance == null) {
            instance = new GUIManager();
        }
        return instance;
    }

   
    public void showMainDashboard() {
        new MainDashboard().setVisible(true);
    }

  
    public void showSignUpWindow() {
        new SignUpWindow().setVisible(true);
    }


    public void showLoginWindow() {
        new LoginWindow().setVisible(true);
    }

    
    public void showStudentStaffDashboard() {
        new StudentStaffDashboard().setVisible(true);
    }

    
    public void showEventOrganiserDashboard() {
        new EventOrganiserDashboard().setVisible(true);
    }

    
    public void showAddEventWindow() {
        new AddEventWindow().setVisible(true);
    }


    public void showUpdateEventWindow() {
        new UpdateEventWindow().setVisible(true);
    }

    public void showCancelEventWindow() {
        new CancelEventWindow().setVisible(true);
    }

    
    public void showViewAttendeesWindow() {
        new ViewAttendeesWindow().setVisible(true);
    }


    public void showEventRegistrationWindow() {
        new EventRegistrationWindow().setVisible(true);
    }


    public void showRegisteredEventWindow() {
        new RegisteredEventWindow().setVisible(true);
    }


    public void showBillWindow() {
        new BillWindow().setVisible(true);
    }


    public void disposeWindow(JFrame frame) {
        if (frame != null) {
            frame.dispose();
        }
    }
}
