
import facade.GUIManager;



// Main.java
public class Main {
    public static void main(String[] args) {
        GUIManager.getInstance().showMainDashboard();
    }
}
