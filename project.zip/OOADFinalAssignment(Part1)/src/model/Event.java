package model;

import java.util.ArrayList;

public class Event {
    private String name;
    private String date;
    private String startTime;
    private String endTime;
    private String venue;
    private String type; 
    private int capacity;
    private double registrationFee; 
    private ArrayList<String> optionalServices;
    private boolean earlyBirdDiscount;
    private boolean staffDiscount;

    public Event(String name, String date, String startTime, String endTime, String venue, String type, int capacity, double registrationFee, ArrayList<String> optionalServices, boolean earlyBirdDiscount, boolean staffDiscount) {
        this.name = name;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        this.venue = venue;
        this.type = type;
        this.capacity = capacity;
        this.registrationFee = registrationFee;
        this.optionalServices = optionalServices != null ? optionalServices : new ArrayList<>();
        this.earlyBirdDiscount = earlyBirdDiscount;
        this.staffDiscount = staffDiscount;
    }

    // Getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }
    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }
    public String getVenue() { return venue; }
    public void setVenue(String venue) { this.venue = venue; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    public double getRegistrationFee() { return registrationFee; }
    public void setRegistrationFee(double registrationFee) { this.registrationFee = registrationFee; }
    public ArrayList<String> getOptionalServices() { return optionalServices; }
    public void setOptionalServices(ArrayList<String> optionalServices) { this.optionalServices = optionalServices; }
    public boolean hasEarlyBirdDiscount() { return earlyBirdDiscount; }
    public void setEarlyBirdDiscount(boolean earlyBirdDiscount) { this.earlyBirdDiscount = earlyBirdDiscount; }
    public boolean hasStaffDiscount() { return staffDiscount; }
    public void setStaffDiscount(boolean staffDiscount) { this.staffDiscount = staffDiscount; }

    // Calculate total fee based on base fee, optional services, and discounts
    

   
    public double getServiceFee(String service) {
        switch (service) {
            case "Catering": return 10.0;
            case "Transportation": return 10.0;
            default: return 0.0;
        }
    }

    
    
    @Override
    public String toString() {
        return name + " (" + type + ") on " + date + " from " + startTime + " to " + endTime + ", Venue: " + venue + ", Capacity: " + capacity + ", Fee: RM" + registrationFee + ", Services: " + optionalServices + ", EarlyBird: " + earlyBirdDiscount + ", Staff: " + staffDiscount;
    }
}

